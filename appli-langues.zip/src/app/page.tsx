import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

const languages = ["Japonais", "Français", "Anglais", "Espagnol"];

const lessons = {
  Japonais: Array.from({ length: 1000 }, (_, i) => ({
    lesson: i % 5 === 0 ? `📘 Leçon : Ceci est une règle importante du japonais numéro ${i + 1}` : null,
    audio: i % 3 === 0 ? `/audio/jp${i % 10}.mp3` : null,
    question: `Quelle est la bonne réponse à cette phrase ? (n°${i + 1})`,
    choices: ["Réponse A", "Réponse B", "Réponse C", "Réponse D"],
    answer: "Réponse B"
  })),
  Français: Array.from({ length: 1000 }, (_, i) => ({
    lesson: i % 5 === 0 ? `📘 Leçon : Ceci est une règle importante du français numéro ${i + 1}` : null,
    audio: i % 3 === 0 ? `/audio/fr${i % 10}.mp3` : null,
    question: `Choisissez la bonne traduction (n°${i + 1})`,
    choices: ["Option 1", "Option 2", "Option 3", "Option 4"],
    answer: "Option 3"
  })),
  Anglais: Array.from({ length: 1000 }, (_, i) => ({
    lesson: i % 5 === 0 ? `📘 Lesson: This is an important English rule number ${i + 1}` : null,
    audio: i % 3 === 0 ? `/audio/en${i % 10}.mp3` : null,
    question: `Select the correct answer (n°${i + 1})`,
    choices: ["Choice A", "Choice B", "Choice C", "Choice D"],
    answer: "Choice D"
  })),
  Espagnol: Array.from({ length: 1000 }, (_, i) => ({
    lesson: i % 5 === 0 ? `📘 Lección: Esta es una regla importante del español número ${i + 1}` : null,
    audio: i % 3 === 0 ? `/audio/es${i % 10}.mp3` : null,
    question: `¿Cuál es la respuesta correcta? (n°${i + 1})`,
    choices: ["Respuesta A", "Respuesta B", "Respuesta C", "Respuesta D"],
    answer: "Respuesta A"
  }))
};

export default function LanguageApp() {
  const [language, setLanguage] = useState("Japonais");
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [history, setHistory] = useState(() => JSON.parse(localStorage.getItem("history") || "[]"));
  const [level, setLevel] = useState(1);
  const [reviewMode, setReviewMode] = useState(false);

  const currentLessons = lessons[language] || [];
  const filteredLessons = reviewMode ? history.filter(h => !h.correct) : currentLessons;
  const current = filteredLessons[step % filteredLessons.length];
  const progress = (step / filteredLessons.length) * 100;

  useEffect(() => {
    localStorage.setItem("history", JSON.stringify(history));
    const totalCorrect = history.filter(h => h.correct).length;
    setXp(totalCorrect * 10);
    setLevel(Math.floor(xp / 100) + 1);
  }, [history, xp]);

  const handleAnswer = (choice) => {
    const correct = choice === current.answer;
    if (correct) setScore(score + 1);
    setHistory([...history, { ...current, userAnswer: choice, correct, step }]);
    setStep((s) => (s + 1));
  };

  const reviewErrors = history.filter(h => !h.correct);

  return (
    <div className="p-4 max-w-md mx-auto space-y-4">
      <h1 className="text-2xl font-bold text-center">🧠 Apprentissage Ludique des Langues</h1>

      <select
        className="w-full p-2 border rounded"
        value={language}
        onChange={(e) => {
          setLanguage(e.target.value);
          setStep(0);
          setScore(0);
        }}
      >
        {languages.map((lang) => (
          <option key={lang} value={lang}>{lang}</option>
        ))}
      </select>

      <div className="flex justify-between items-center text-sm">
        <p className="text-left">🔥 XP : {xp} | Niveau : {level}</p>
        <button onClick={() => setReviewMode(!reviewMode)} className="text-xs border px-2 py-1 rounded">
          {reviewMode ? "🔁 Mode normal" : "🔁 Mode révision"}
        </button>
      </div>

      <Progress value={progress} className="h-2" />
      <p className="text-sm text-right">Progression : {Math.round(progress)}%</p>

      {current.lesson && (
        <Card className="bg-blue-50">
          <CardContent className="py-2">
            <p className="text-blue-700 font-semibold">{current.lesson}</p>
          </CardContent>
        </Card>
      )}

      {current.audio && (
        <div className="text-center">
          <audio controls src={current.audio} className="mx-auto" />
        </div>
      )}

      <Card>
        <CardContent className="py-4">
          {current ? (
            <>
              <p className="text-lg font-semibold">🔸 {current.question}</p>
              <div className="mt-4 grid gap-2">
                {current.choices.map((choice, idx) => (
                  <Button
                    key={idx}
                    onClick={() => handleAnswer(choice)}
                    variant="outline"
                  >
                    {choice}
                  </Button>
                ))}
              </div>
            </>
          ) : (
            <p>Aucune leçon disponible pour cette langue pour le moment.</p>
          )}
        </CardContent>
      </Card>

      <div className="text-sm text-gray-700">Score : {score} / {history.length}</div>

      <Card>
        <CardContent className="py-2">
          <p className="font-semibold mb-2">📚 Historique :</p>
          {history.length === 0 ? (
            <p>Pas encore d'historique.</p>
          ) : (
            <ul className="list-disc ml-4 space-y-1 max-h-32 overflow-y-auto">
              {history.map((item, idx) => (
                <li key={idx} className={item.correct ? "text-green-600" : "text-red-600"}>
                  {item.question} → {item.correct ? `✅ ${item.userAnswer}` : `❌ ${item.userAnswer} (✔ ${item.answer})`}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {reviewErrors.length > 0 && !reviewMode && (
        <Card>
          <CardContent className="py-2">
            <p className="font-semibold mb-2 text-yellow-700">🔁 À revoir :</p>
            <ul className="list-disc ml-4 space-y-1">
              {reviewErrors.map((item, idx) => (
                <li key={idx}>{item.question} ❌ (✔ {item.answer})</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}